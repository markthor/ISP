package connectFour;
/*
 * Utility heuristics must implement this interface.
 */
public interface IUtility {
	public double utility(int[][] gameBoard);
}
